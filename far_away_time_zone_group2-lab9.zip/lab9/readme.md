idea for designing for interactive web page: the main purpose of the page is to input the stu's information and display the information we have saved, 
so we are aiming to design a web page with simplicity without losing beauty. We applied gentle color to avoid distracting users from checking their status, and used most simple form without any extra style to display the information,
to make sure that users could quickly locate the content they would like to find.
For the php part, we allow the users to add the information to the students table, courses table, and grades table. After user clicks on the add address button, the address part in the table and the input textbox for the address will appear simultaneously. Same for the Add section and year button for the Courses table. When user clicks on the create grades table button, the grades table in the database will be created and will also show on the webpage. 
When user clicks on grade higher than 90 button, it will show the output of the corresponding query in a table format. The same as the Average Grade for each Course button and Number of Student in each course button.

We put the command and the MySQL output in lab9.txt.
Also, the lab9.sql is the file that only includes our command line.

What we did:

Jonathan Yang: Helped to modify part1 and did half of part2

Jiahui Wu: Finished part1 and did some part2

Jensen Chen: Helped to finish the part3: finished the stylesheet

Shuhan Li: Helped to complete part2

Jennifer Zhan: Finished part3 and helped with stylesheet

reference:
https://www.w3schools.com/
https://stackoverflow.com